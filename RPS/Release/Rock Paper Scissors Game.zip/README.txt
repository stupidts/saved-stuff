Make sure you have a folder in your C drive called Temp
C:\Temp

If this folder doesn't exist your data will not be saved!